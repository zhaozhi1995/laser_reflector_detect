﻿/**
 * @file /src/qnode.cpp
 *
 * @brief Ros communication central!
 *
 * @date February 2011
 **/

/*****************************************************************************
** Includes
*****************************************************************************/

#include <ros/ros.h>
#include <ros/network.h>
#include <string>
#include <std_msgs/String.h>
#include <sstream>
#include "../include/ros_qt5/qnode.h"
#include "visualization_msgs/MarkerArray.h"
#include "math.h"

#define VISUAL_RVIZ

/*****************************************************************************
** Namespaces
*****************************************************************************/

namespace qt_test
{

    /*****************************************************************************
** Implementation
*****************************************************************************/

    QNode::QNode(int argc, char **argv) : init_argc(argc),
                                          init_argv(argv)
    {
    }

    QNode::~QNode()
    {
        if (ros::isStarted())
        {
            ros::shutdown(); // explicitly needed since we use ros::start();
            ros::waitForShutdown();
        }
        wait();
    }

    bool QNode::init()
    {
        ROS_INFO("ros master start init");
        ros::init(init_argc, init_argv, "laser_reflector_detect_node");
        ROS_INFO("ros master finish init");
        if (!ros::master::check())
        {
            ROS_INFO("ros master fail");
            return false;
        }
        else
        {
            ROS_INFO("ros master success");
        }
        ros::start(); // explicitly needed since our nodehandle is going out of scope.
        ros::NodeHandle n;
        // Add your ros communications here.

        ros::param::get("/laser_reflector_detect_node/angle_error_scale", angle_error_scale);
        ros::param::get("/laser_reflector_detect_node/distance_error_scale", distance_error_scale);
        ros::param::get("/laser_reflector_detect_node/reflector_radius", reflector_radius);
        ros::param::get("/laser_reflector_detect_node/min_reflector_sample_count", min_reflector_sample_count);
        ros::param::get("/laser_reflector_detect_node/reflector_intensity", reflector_intensity);
        ros::param::get("/laser_reflector_detect_node/kLandmarkMarkerScale", kLandmarkMarkerScale);
        ros::param::get("/laser_reflector_detect_node/reflector_combined_length", reflector_combined_length);
        ros::param::get("/laser_reflector_detect_node/reflector_combination_mode", reflector_combination_mode);

        chatter_publisher = n.advertise<std_msgs::String>("chatter", 1000);

        scan_sub_ = n.subscribe("/scan", 1, &QNode::callback, this);

        //debug_points_ = n.advertise<sensor_msgs::PointCloud2>("dock_points",10);

        reflector_points_ = n.advertise<geometry_msgs::PointStamped>("reflector_points", 1);

        reflector_landmark_ = n.advertise<cartographer_ros_msgs::LandmarkList>("Laserlandmark", 1);

        landmark_poses_list_publisher_ = n.advertise<::visualization_msgs::MarkerArray>("laser_landmark_list_test", 1);

        start();
        return true;
    }

    bool QNode::init(const std::string &master_url, const std::string &host_url)
    {
        std::map<std::string, std::string> remappings;
        remappings["__master"] = master_url;
        remappings["__hostname"] = host_url;
        ros::init(remappings, "qt_test");
        if (!ros::master::check())
        {
            return false;
        }
        ros::start(); // explicitly needed since our nodehandle is going out of scope.
        ros::NodeHandle n;
        // Add your ros communications here.
        chatter_publisher = n.advertise<std_msgs::String>("chatter", 1000);
        start();
        return true;
    }

    void QNode::run()
    {
        ros::Rate loop_rate(30);
        int count = 0;
        while (ros::ok())
        {
            /*
		std_msgs::String msg;
		std::stringstream ss;
		ss << "hello world " << count;
		msg.data = ss.str();
		chatter_publisher.publish(msg);
		log(Info,std::string("I sent: ")+msg.data);
        */
            ros::spinOnce();
            loop_rate.sleep();
            ++count;
        }
        std::cout << "Ros shutdown, proceeding to close the gui." << std::endl;
        Q_EMIT rosShutdown(); // used to signal the gui for a shutdown (useful to roslaunch)
    }

    void QNode::log(const LogLevel &level, const std::string &msg)
    {
        logging_model.insertRows(logging_model.rowCount(), 1);
        std::stringstream logging_model_msg;
        switch (level)
        {
        case (Debug):
        {
            ROS_DEBUG_STREAM(msg);
            logging_model_msg << "[DEBUG] [" << ros::Time::now() << "]: " << msg;
            break;
        }
        case (Info):
        {
            ROS_INFO_STREAM(msg);
            logging_model_msg << "[INFO] [" << ros::Time::now() << "]: " << msg;
            break;
        }
        case (Warn):
        {
            ROS_WARN_STREAM(msg);
            logging_model_msg << "[INFO] [" << ros::Time::now() << "]: " << msg;
            break;
        }
        case (Error):
        {
            ROS_ERROR_STREAM(msg);
            logging_model_msg << "[ERROR] [" << ros::Time::now() << "]: " << msg;
            break;
        }
        case (Fatal):
        {
            ROS_FATAL_STREAM(msg);
            logging_model_msg << "[FATAL] [" << ros::Time::now() << "]: " << msg;
            break;
        }
        }
        QVariant new_row(QString(logging_model_msg.str().c_str()));
        logging_model.setData(logging_model.index(logging_model.rowCount() - 1), new_row);
        Q_EMIT loggingUpdated(); // used to readjust the scrollbar
    }

    void QNode::callback(const sensor_msgs::LaserScanConstPtr &scan)
    {
        //scan_ = scan;

        //laser_processor::SampleSet* cluster = new laser_processor::SampleSet;

        std::vector<laser_processor::Sample *> scan_filter;

        for (uint32_t i = 0; i < scan->ranges.size(); i++)
        {
            laser_processor::Sample *s = laser_processor::Sample::Extract(i, reflector_intensity, *scan);

            if (s != NULL)
            {
                //cluster->insert(s);
                scan_filter.push_back(s);
            }
        }

        if (scan_filter.size() == 0)
            return;

        //get the center of reflector
        double center_x, center_y, center_yaw, center_count;
        std::vector<Reflector_pos> reflectors_;
        double last_item_x, last_item_y;
        bool is_mark_start = true;

        //for(laser_processor::SampleSet::iterator p = cluster->begin(); p != cluster->end(); p++)
        for (int i = 0; i < scan_filter.size(); i++)
        {
            is_mark_start = true;

            for (int j = i; j < scan_filter.size(); j++)
            {
                laser_processor::Sample *p = scan_filter[j];

                double item_x = p->x;
                double item_y = p->y;
                double item_range = p->range;

                if (is_mark_start == true)
                {
                    center_x = p->x;
                    center_y = p->y;
                    center_count = 1;
                    is_mark_start = false;
                }
                else
                {
                    double d_x = item_x - last_item_x;
                    double d_y = item_y - last_item_y;
                    double d_xy = sqrt(pow(d_x, 2) + pow(d_y, 2));
                    double angle_internal = d_xy / item_range;
                    double distance_internal = scan->angle_increment * item_range;

                    angle_error = scan->angle_increment * angle_error_scale;
                    distance_error = distance_internal * distance_error_scale;

                    //check the scan point not the last one
                    if ((angle_internal < angle_error || d_xy < distance_error) && (j != scan_filter.size() - 1))
                    {
                        center_x += p->x;
                        center_y += p->y;
                        center_count++;
                    }
                    else
                    {
                        if (center_count > min_reflector_sample_count)
                        {
                            center_x /= center_count;
                            center_y /= center_count;
                            center_yaw = atan2(center_y, center_x);

                            center_x += cos(center_yaw) * reflector_radius;
                            center_y += sin(center_yaw) * reflector_radius;

                            Reflector_pos item;
                            item.center_x = center_x;
                            item.center_y = center_y;
                            item.center_yaw = center_yaw;
                            reflectors_.push_back(item);
                        }

                        center_x = 0.0;
                        center_y = 0.0;
                        center_count = 0;
                        i = j - 1;
                        break;
                    }
                }

                last_item_x = item_x;
                last_item_y = item_y;
            }
        }

        visualization_msgs::MarkerArray landmark_poses_list;
        cartographer_ros_msgs::LandmarkList reflector_LandMarkList;

        /*
    //old data
    //log(Info,"peak check the size " + std::to_string((reflectors_.size())));
    
        for(int i = 0 ; i < reflectors_.size(); i++)
        {
            Reflector_pos item = reflectors_[i];

            //publish the center points
            
            geometry_msgs::PointStamped point;
            point.header.stamp = scan->header.stamp;
            point.header.frame_id = "car_laser";

            point.point.x = item.center_x;
            point.point.y = item.center_y;
            point.point.z = 0;

            reflector_points_.publish(point);
            
            double distance = sqrt(pow(item.center_x,2) + pow(item.center_y,2));
            if(distance < 1.5) continue;
            //
            cartographer_ros_msgs::LandmarkEntry reflector_LandMarkEntry;
            reflector_LandMarkEntry.id = "landmark_1"; //"unknown"
            reflector_LandMarkEntry.tracking_from_landmark_transform.position.x = item.center_x;
            reflector_LandMarkEntry.tracking_from_landmark_transform.position.y = item.center_y;
            reflector_LandMarkEntry.tracking_from_landmark_transform.position.z = 0.0;
            tf::Quaternion quat = tf::createQuaternionFromYaw(item.center_yaw);
            log(Info, "item.center_yaw : " + std::to_string(item.center_yaw));
            reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.x = quat.x();
            reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.y = quat.y();
            reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.z = quat.z();
            reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.w = quat.w();
            reflector_LandMarkEntry.translation_weight = 1.0;
            reflector_LandMarkEntry.rotation_weight = 1.0;
            reflector_LandMarkEntry.type = "reflector_combined";

            reflector_LandMarkList.header.frame_id = "Laser_Landmark";
            reflector_LandMarkList.header.stamp = scan->header.stamp; //ros::Time::now();
            reflector_LandMarkList.landmarks.push_back(reflector_LandMarkEntry);

            #ifdef VISUAL_RVIZ
            visualization_msgs::Marker landmark_item;
            landmark_item.pose.position.x = item.center_x;
            landmark_item.pose.position.y = item.center_y;
            landmark_item.pose.orientation.x = quat.x();
            landmark_item.pose.orientation.y = quat.y();
            landmark_item.pose.orientation.z = quat.z();
            landmark_item.pose.orientation.w = quat.w();
            landmark_item.header.frame_id = "car_laser";
            landmark_item.header.stamp = ros::Time(0); //ros::Time::now();
            landmark_item.scale.x = kLandmarkMarkerScale;
            landmark_item.scale.y = kLandmarkMarkerScale;
            landmark_item.scale.z = kLandmarkMarkerScale;
            landmark_item.type = visualization_msgs::Marker::SPHERE;
            landmark_item.ns = "Landmarks";
            landmark_item.id = i;
            landmark_item.color.a = 1.0;
            landmark_item.color.r = 0;
            landmark_item.color.g = 255;
            landmark_item.color.b = 0;
            landmark_item.lifetime = ros::Duration(0.02);

            landmark_poses_list.markers.push_back(landmark_item);
           #endif

           //break;

        }
        */

        //use two reflector as a landmark
        //log(Info, "reflectors_ size " + std::to_string(reflectors_.size() ));
        if (reflectors_.size() < 2)
            return;

        double origin_x, origin_y, origin_theta;

        if (reflector_combination_mode == 2 && reflectors_.size() == 2)
        {
            for (int i = 0; i < reflectors_.size(); i++)
            {
                Reflector_pos item_i = reflectors_[i];
                //log(Info, "item_i.center_yaw : " + std::to_string(item_i.center_yaw));

                for (int j = i + 1; j < reflectors_.size(); j++)
                {
                    Reflector_pos item_j = reflectors_[j];
                    //log(Info, "item_j.center_yaw : " + std::to_string(item_j.center_yaw));

                    double x_ij = fabs(item_i.center_x - item_j.center_x);
                    double y_ij = fabs(item_i.center_y - item_j.center_y);
                    double distance_ij = sqrt(pow(x_ij, 2) + pow(y_ij, 2));
                    //log(Info, "item_i.center_x : " + std::to_string(item_i.center_x));
                    //log(Info, "item_i.center_y : " + std::to_string(item_i.center_y));
                    //log(Info, "item_j.center_x : " + std::to_string(item_j.center_x));
                    //log(Info, "item_j.center_y : " + std::to_string(item_j.center_y));
                    //log(Info, "x_ij : " + std::to_string(x_ij));
                    //log(Info, "y_ij : " + std::to_string(y_ij));
                    //log(Info, "distance_ij : " + std::to_string(distance_ij));

                    //if two reflectors not arrange by special mode, jump out
                    if (fabs(distance_ij - reflector_combined_length) > 0.2)
                        continue;

                    double distance_i = sqrt(pow(item_i.center_x, 2) + pow(item_i.center_y, 2));
                    double distance_j = sqrt(pow(item_j.center_x, 2) + pow(item_j.center_y, 2));

                    double coord_x, coord_y, coord_theta;

                    if (fabs(item_i.center_yaw - item_j.center_yaw) < M_PI)
                    {
                        if (item_i.center_yaw > item_j.center_yaw)
                        {
                            //item_i is origin
                            double up_value = pow(distance_i, 2) + pow(distance_ij, 2) - pow(distance_j, 2);
                            double down_value = 2 * distance_i * distance_ij;
                            double cos_theta = acos(up_value / down_value);
                            coord_x = cos(cos_theta) * distance_i;
                            coord_y = sin(cos_theta) * distance_i;
                            origin_x = item_i.center_x;
                            origin_y = item_i.center_y;
                            origin_theta = atan2(1, 0) - atan2(item_j.center_y - item_i.center_y, item_j.center_x - item_i.center_x);
                            if (origin_theta > M_PI)
                            {
                                origin_theta -= 2 * M_PI;
                            }
                            if (origin_theta < -M_PI)
                            {
                                origin_theta += 2 * M_PI;
                            }
                        }
                        else
                        {
                            //item_j is origin
                            double up_value = pow(distance_j, 2) + pow(distance_ij, 2) - pow(distance_i, 2);
                            double down_value = 2 * distance_j * distance_ij;
                            double cos_theta = acos(up_value / down_value);
                            coord_x = cos(cos_theta) * distance_j;
                            coord_y = sin(cos_theta) * distance_j;
                            coord_theta = atan2(coord_y, coord_x);
                            origin_x = item_j.center_x;
                            origin_y = item_j.center_y;
                            origin_theta = atan2(1, 0) - atan2(item_i.center_y - item_j.center_y, item_i.center_x - item_j.center_x);
                            if (origin_theta > M_PI)
                            {
                                origin_theta -= 2 * M_PI;
                            }
                            if (origin_theta < -M_PI)
                            {
                                origin_theta += 2 * M_PI;
                            }
                        }
                    }
                    else
                    {
                        if (item_i.center_yaw < item_j.center_yaw)
                        {
                            //item_i is origin
                            double up_value = pow(distance_i, 2) + pow(distance_ij, 2) - pow(distance_j, 2);
                            double down_value = 2 * distance_i * distance_ij;
                            double cos_theta = acos(up_value / down_value);
                            coord_x = cos(cos_theta) * distance_i;
                            coord_y = sin(cos_theta) * distance_i;
                            coord_theta = atan2(coord_y, coord_x);
                            origin_x = item_i.center_x;
                            origin_y = item_i.center_y;
                            origin_theta = atan2(1, 0) - atan2(item_j.center_y - item_i.center_y, item_j.center_x - item_i.center_x);
                            if (origin_theta > M_PI)
                            {
                                origin_theta -= 2 * M_PI;
                            }
                            if (origin_theta < -M_PI)
                            {
                                origin_theta += 2 * M_PI;
                            }
                        }
                        else
                        {
                            //item_j is origin
                            double up_value = pow(distance_j, 2) + pow(distance_ij, 2) - pow(distance_i, 2);
                            double down_value = 2 * distance_j * distance_ij;
                            double cos_theta = acos(up_value / down_value);
                            coord_x = cos(cos_theta) * distance_j;
                            coord_y = sin(cos_theta) * distance_j;
                            coord_theta = atan2(coord_y, coord_x);
                            origin_x = item_j.center_x;
                            origin_y = item_j.center_y;
                            origin_theta = atan2(1, 0) - atan2(item_i.center_y - item_j.center_y, item_i.center_x - item_j.center_x);
                            if (origin_theta > M_PI)
                            {
                                origin_theta -= 2 * M_PI;
                            }
                            if (origin_theta < -M_PI)
                            {
                                origin_theta += 2 * M_PI;
                            }
                        }
                    }

                    //log(Info, "origin_x : " + std::to_string(origin_x));
                    //log(Info, "origin_y : " + std::to_string(origin_y));
                    //log(Info, "origin_theta : " + std::to_string(origin_theta));

                    /*
            Reflector_pos item;
            item.center_x = (item_i.center_x + item_j.center_x) / 2;
            item.center_y = (item_i.center_y + item_j.center_y) / 2;
            item.center_yaw = atan2(item.center_y , item.center_x);// + M_PI_2;
            log(Info, "item_i.center_yaw : " + std::to_string(item_i.center_yaw));
            log(Info, "item_j.center_yaw : " + std::to_string(item_j.center_yaw));
            //log(Info, "item.center_yaw : " + std::to_string(item.center_yaw));


            //publish the center points
            geometry_msgs::PointStamped point;
            point.header.stamp = scan->header.stamp;
            point.header.frame_id = "car_laser";

            point.point.x = item.center_x;
            point.point.y = item.center_y;
            point.point.z = 0;

            reflector_points_.publish(point);
            */
                }
            }
        }

        if (reflector_combination_mode == 3 && reflectors_.size() == 3)
        {
            Reflector_pos item_j, item_k;

            for (int i = 0; i < reflectors_.size(); i++)
            {
                Reflector_pos item_i = reflectors_[i];

                switch (i)
                {
                case 0:
                    item_j = reflectors_[1];
                    item_k = reflectors_[2];
                    break;
                case 1:
                    item_j = reflectors_[0];
                    item_k = reflectors_[2];
                    break;
                case 2:
                    item_j = reflectors_[0];
                    item_k = reflectors_[1];
                    break;
                }

                double theta_1 = atan2(item_i.center_y - item_j.center_y, item_i.center_x - item_j.center_x);
                double theta_2 = atan2(item_i.center_y - item_k.center_y, item_i.center_x - item_k.center_x);

                //degree detect error is not less 20
                double f_theta = fabs(theta_1 - theta_2);
                if (fabs(f_theta - M_PI / 2) > M_PI / 9)
                    continue;

                //if satisfy condition (less 20) then
                double x_ij = fabs(item_i.center_x - item_j.center_x);
                double y_ij = fabs(item_i.center_y - item_j.center_y);
                double distance_ij = sqrt(pow(x_ij, 2) + pow(y_ij, 2));
                double x_ik = fabs(item_i.center_x - item_j.center_x);
                double y_ik = fabs(item_i.center_y - item_j.center_y);
                double distance_ik = sqrt(pow(x_ik, 2) + pow(y_ik, 2));

                if (distance_ij > distance_ik)
                {
                    //ij is the axis x
                    origin_theta = atan2(1, 0) - atan2(item_i.center_y - item_j.center_y, item_i.center_x - item_j.center_x);
                }
                else
                {
                    //ik is the axis_x
                    origin_theta = atan2(1, 0) - atan2(item_i.center_y - item_k.center_y, item_i.center_x - item_k.center_x);
                }

                origin_x = item_i.center_x;
                origin_y = item_i.center_y;
            }
        }

        double distance = sqrt(pow(origin_x, 2) + pow(origin_y, 2));
        if (distance < 1.0)
            return;
        //
        cartographer_ros_msgs::LandmarkEntry reflector_LandMarkEntry;
        reflector_LandMarkEntry.id = "landmark_1";
        reflector_LandMarkEntry.tracking_from_landmark_transform.position.x = origin_x;
        reflector_LandMarkEntry.tracking_from_landmark_transform.position.y = origin_y;
        reflector_LandMarkEntry.tracking_from_landmark_transform.position.z = 0;
        tf::Quaternion quat = tf::createQuaternionFromYaw(-1.0 * origin_theta);
        reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.x = quat.x();
        reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.y = quat.y();
        reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.z = quat.z();
        reflector_LandMarkEntry.tracking_from_landmark_transform.orientation.w = quat.w();
        reflector_LandMarkEntry.translation_weight = 1.0;
        reflector_LandMarkEntry.rotation_weight = 1.0;
        reflector_LandMarkEntry.type = "reflector_combined";

        reflector_LandMarkList.header.frame_id = "car_laser";
        reflector_LandMarkList.header.stamp = scan->header.stamp; //ros::Time::now();
        reflector_LandMarkList.landmarks.push_back(reflector_LandMarkEntry);

#ifdef VISUAL_RVIZ
        visualization_msgs::Marker landmark_item;
        landmark_item.pose.position.x = origin_x;
        landmark_item.pose.position.y = origin_y;
        landmark_item.pose.orientation.x = 0.0;
        landmark_item.pose.orientation.y = 0.0;
        landmark_item.pose.orientation.z = 0.0;
        landmark_item.pose.orientation.w = 1.0;
        landmark_item.header.frame_id = "car_laser";
        landmark_item.header.stamp = scan->header.stamp; //ros::Time::now();
        landmark_item.scale.x = kLandmarkMarkerScale;
        landmark_item.scale.y = kLandmarkMarkerScale;
        landmark_item.scale.z = kLandmarkMarkerScale;
        landmark_item.type = visualization_msgs::Marker::SPHERE;
        landmark_item.ns = "Landmarks";
        landmark_item.id = reflector_LandMarkList.landmarks.size();
        landmark_item.color.a = 1.0;
        landmark_item.color.r = 0;
        landmark_item.color.g = 255;
        landmark_item.color.b = 0;
        landmark_item.lifetime = ros::Duration(0.05);

        landmark_poses_list.markers.push_back(landmark_item);
#endif

        if (reflector_LandMarkList.landmarks.size() != 0)
        {
            reflector_landmark_.publish(reflector_LandMarkList);

#ifdef VISUAL_RVIZ
            //log(Info, "landmark_poses_list size " + std::to_string(landmark_poses_list.markers.size()));
            landmark_poses_list_publisher_.publish(landmark_poses_list);
#endif
        }
    }
} // namespace qt_test
